# Project1

Terminal Commands to make the .o files:
- ca65 src/reset.asm
- ca65 src/sprites.asm
